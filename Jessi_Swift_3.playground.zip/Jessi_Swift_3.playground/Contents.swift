import UIKit

// Parent Class - Computers
class Computer {
    private var brand: String
    private var processor: String
    private var ram: Int

init(brand: String, processor: String, ram: Int) {
self.brand = brand
self.processor = processor
self.ram = ram
    }

// Print function
func displaySpecs() {
print("Brand: \(self.brand), Processor: \(self.processor), RAM: \(self.ram) GB")
    }
func getBrand() -> String {
return self.brand
    }
func getProcessor() -> String {
return self.processor
    }
func getRam() -> Int {
return self.ram
}
}

// Laptop Subclass
class Laptop: Computer {
private var isTouchscreen: Bool

init(brand: String, processor: String, ram: Int, isTouchscreen: Bool) {
self.isTouchscreen = isTouchscreen
super.init(brand: brand, processor: processor, ram: ram)
    }
    
// Override function to display new properties
override func displaySpecs() {
super.displaySpecs()
print("Touchscreen: \(self.isTouchscreen ? "Yes,touchscreens make designing UI so much easier!" : "No")")
}
}

// Desktop Subclass
class Desktop: Computer {
private var hasDedicatedGPU: Bool

init(brand: String, processor: String, ram: Int, hasDedicatedGPU: Bool) {
self.hasDedicatedGPU = hasDedicatedGPU
super.init(brand: brand, processor: processor, ram: ram)
    }
    
override func displaySpecs() {
super.displaySpecs()
print("Dedicated GPU: \(self.hasDedicatedGPU ? "Yes" : "No,this system comes with AMD Radeon™ 760M Graphics")")
    }
}

// Server Subclass
class Server: Computer {
private var rackUnits: Int

init(brand: String, processor: String, ram: Int, rackUnits: Int) {
self.rackUnits = rackUnits
super.init(brand: brand, processor: processor, ram: ram)
    }

override func displaySpecs() {
super.displaySpecs()
print("Rack Units: \(self.rackUnits)")
    }
}

// Test Code - Subclass - Laptop
print("~Laptop Specs~")
let laptopSpecs =
Laptop(brand: "Acer",processor: "Intel® Celeron® N4020 Dual-core 1.10 GHz",ram: 4,isTouchscreen: true)
laptopSpecs.displaySpecs()
print("")

//Test Code - Subclass - Desktop
print("~Desktop Specs~")
let DesktopSpecs = Desktop(brand: "HP", processor: "AMD Ryzen™ 5 8600G", ram: 16, hasDedicatedGPU: false)
DesktopSpecs.displaySpecs()
print("")

//Test Code - Subclass - Server
print("~Server Specs~")
let ServerSpecs = Server(brand: "Dell", processor: "Intel® Core™ i7-1065G7", ram: 32, rackUnits: 2)
ServerSpecs.displaySpecs()

